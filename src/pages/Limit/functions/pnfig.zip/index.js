/*
    This is a backend nodejs 
    that interacts with the 1inch
    Limit Api
*/
import {useState} from 'react';
import Web3 from "web3";
import {ethers} from "ethers";
// import limit from '@1inch/limit-order-protocol';
// import LimitOrderBuilder from '@1inch/limit-order-protocol/limit-order.builder';
// import LimitOrderProtocolFacade from '@1inch/limit-order-protocol/limit-order-protocol.facade';
// import Web3ProviderConnector from '@1inch/limit-order-protocol/connector/web3-provider.connector';
import {
    LimitOrderBuilder,
    LimitOrderProtocolFacade,
    Web3ProviderConnector,
} from '@1inch/limit-order-protocol';


import config from "./config";
import { limitAbi, tokenAbi } from "./abi.js";
import { ZERO_ADDRESS } from 'src/constants';
let web3 = null
let limitWalletAddress = ""



function useLimit(){
    


    //this sets up the web3 provider
    async function setProvider(webProvider){
        if(typeof webProvider === 'string'){
            web3 = new Web3(new Web3.providers.HttpProvider(webProvider));
            return Promise.resolve(true)
        }
        else{
            try{
                let res = await window.ethereum.request({method: 'eth_requestAccounts'})
                if(res){
                    web3 = new Web3(webProvider);
                    limitWalletAddress = res[0]
                    //listens to account changed
                    window.ethereum.on('accountsChanged', (acct =>{
                        limitWalletAddress = res[0]
                    }));
                    return true
                }
                else throw new Error('Accounts changed error');
            }
            catch(e){
                return false
            }
        }
    }


    /*
    this functions verify if 1inch has permission
    to spend the ERC20 tokens. If no permission
    it requests allowance. Always run this first
    */
    async function isAllowed(_tokenAddress, chainId){
        try{
           // console.log({limitWalletAddress, _tokenAddress }, config.chains[chainId]);
            if(limitWalletAddress.trim() !== "" && _tokenAddress.trim() !== ""){
                const tokenz = new web3.eth.Contract(tokenAbi, _tokenAddress);
                tokenz.setProvider(web3);
                let amt = await tokenz.methods.allowance(limitWalletAddress, config.chains[chainId]).call();
               // console.log(amt)
                if(amt * 1 <= 0){return Promise.resolve(false)
                }
		
		return Promise.resolve(true)
            }
            else throw new Error('Limit address is empty');
        }catch(err){ 
            return false
        }
    }
    
    async function getAllowed(_tokenAddress, chainId, _ether){
        try{
            console.log({limitWalletAddress, _tokenAddress, chainId});
//            if(limitWalletAddress.trim() !== "" ){
//                const tokenz = new web3.eth.Contract(abi, _tokenAddress);
//                //get approval asap
//                let res = await tokenz.methods.approve(config.chains[chainId], Web3.utils.toWei('900000000')).send({from: limitWalletAddress})
//                //done successfully
//                if(res.status) return true;
//                else throw new Error('Could not approve account');
//            }
              if(limitWalletAddress.trim() !== "" && _tokenAddress.trim() !== "") {
                  const signer = _ether.getSigner();
                  const token = new ethers.Contract(_tokenAddress, tokenAbi, signer);
                  let res = await token.approve(config.chains[chainId],  Web3.utils.toWei('9000000000000000000'))
                  if(res.hash) {
                      res = await res.wait()//done successfully
                      if(res.status) return true;
                      else throw new Error('Could not approve account');
                  }
                  else throw new Error('Could not approve account');
              }
              else throw new Error('Limit address is empty');
        }catch(err){ console.log(err)
            return false
        }
    }


    //to fill a limit order
    async function fillLimit(order, chainId, sign, _ether){
        //convert order to array 
        const _order = [order.salt, order.makerAsset, order.takerAsset, order.maker, ZERO_ADDRESS, ZERO_ADDRESS, order.makingAmount, order.takingAmount, "0x00", "0x00"]
        const contractAddress = config.chains[chainId];
        const signer = _ether.getSigner();
        const limit = new ethers.Contract(contractAddress, limitAbi, signer);
        const res = await limit.fillOrderWith(_order, sign)
        return res  
    }

 
    

    return {
        monitorTx,
        limitWalletAddress,
        cancelLimit,
        newLimit,
        setProvider,
        getAllowed,
        isAllowed
    }
}


 

export default useLimit;